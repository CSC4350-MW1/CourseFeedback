package com.example.coursefeedback;


import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class multChoice_survey extends MainActivity {

    RadioGroup rg_goodScale;
    Button next_btn;
    int index;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question1);

        rg_goodScale = findViewById(R.id.rg_goodScale);
        next_btn = findViewById(R.id.next_btn);
        next_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int checkID = rg_goodScale.getCheckedRadioButtonId();
                if(checkID == -1) {
                    //Radio buttons are not checked
                    showMsg.message(getApplicationContext(),"Please select an option.");
                }
                else {
                    findRadioButton(checkID);
                    nextQuestion();
                }
            }
        });

    }
    public void nextQuestion() {
        Intent intent = new Intent(this, multChoice_survey2.class);
        startActivity(intent);
    }

    private void findRadioButton(int checkID) {
        switch (checkID) {
            case R.id.radio_btn1:
                break;
            case R.id.radio_btn2:
                break;
            case R.id.radio_btn3:
                break;
            case R.id.radio_btn4:
                break;
            case R.id.radio_btn5:
                break;
        }
    }

}
