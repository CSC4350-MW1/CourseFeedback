package com.example.coursefeedback;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class multChoice_survey2 extends MainActivity{
    RadioGroup rg_goodScale;
    Button next_btn;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question2);

        rg_goodScale = findViewById(R.id.rg_goodScale);
        next_btn = findViewById(R.id.next_btn);
        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkID = rg_goodScale.getCheckedRadioButtonId();
                if(checkID == -1) {
                    //Radio buttons are not checked
                    showMsg.message(getApplicationContext(),"Please select an option.");
                }
                else {
                    findRadioButton(checkID);
                    nextQuestion();
                }
            }
        });
    }
    public void nextQuestion() {
        Intent intent = new Intent(this, multChoice_survey3.class);
        startActivity(intent);
    }

    private void findRadioButton(int checkID) {
        switch (checkID) {
            case R.id.radio_btn1:
                break;
            case R.id.radio_btn2:
                break;
            case R.id.radio_btn3:
                break;
            case R.id.radio_btn4:
                break;
            case R.id.radio_btn5:
                break;
        }
    }

}

