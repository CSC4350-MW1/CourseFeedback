package com.example.coursefeedback;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton radio_btn1, radio_btn2, radio_btn3, radio_btn4, radio_btn5;
    Button next_btn, terms_btn, refresh_btn, home_btn;
    TextView app_name, appbar_title, refresh_text, terms_text, survey_question, poor, fair, good, very_good, excellent, next, grading, very_slow, slow, normal, fast, very_fast, overall_pace, overall_quality;
    ImageView gsu_logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CHANGE_WIFI_STATE, Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                PackageManager.PERMISSION_GRANTED);

        terms_btn = (Button) findViewById(R.id.terms_btn);
        terms_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(buttongetSSID(v))
                    courseDropdown();
            }
        });
    }

    public void courseDropdown() {
        Intent intent = new Intent(this, selectCourse.class);
        startActivity(intent);
    }

    public boolean buttongetSSID(View v){
        WifiManager wifimanager = (WifiManager) this.getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo;
        wifiInfo = wifimanager.getConnectionInfo();
        if(wifiInfo.getSupplicantState() == SupplicantState.COMPLETED){
            String ssid = wifiInfo.getSSID().toString();
            System.out.println(ssid);
            if(ssid.equalsIgnoreCase("\"AndroidWifi\""))
                return true;
            else {
                String wifi_not_correct = "Please connect to GSU wifi and turn on location.";
                Toast.makeText(this.getApplicationContext(), wifi_not_correct, Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else{
            String wifi_not_found = "Wifi not found. Please check location and permissions.";
            Toast.makeText(this.getApplicationContext(), wifi_not_found, Toast.LENGTH_SHORT).show();
            return false;

        }

    }
}



