package com.example.coursefeedback;

import android.os.Bundle;
import android.widget.AdapterView;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;


public class selectCourse extends MainActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_course);

        Button course_next;
        course_next = findViewById(R.id.course_next);
        course_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSessions();
            }
        });

        String[] courses = {"CSC 1101", "CSC 1102", "CSC 2720", "CSC 3320", "CSC 4350", "CSC 4820"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, courses);
        AutoCompleteTextView ddl = (AutoCompleteTextView) findViewById(R.id.ddList);
        ddl.setAdapter(adapter);

        ddl.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                course_next.setEnabled(true);
            }
        });
    }

    public void openSessions() {
        Intent intent = new Intent(this, selectSession.class);
        startActivity(intent);
    }
}