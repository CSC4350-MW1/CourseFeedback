package com.example.coursefeedback;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;


public class selectSession extends MainActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_session);

        Button session_next;
        session_next = findViewById(R.id.session_next);
        session_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openQuestions();
            }
        });

        String[] sessions = {"#1", "#2", "#3"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, sessions);
        AutoCompleteTextView ddl = (AutoCompleteTextView) findViewById(R.id.ddList);
        ddl.setAdapter(adapter);

        ddl.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                session_next.setEnabled(true);
            }
        });
    }

    public void openQuestions() {
        Intent intent = new Intent(this, multChoice_survey.class);
        startActivity(intent);
    }
}
