package com.example.coursefeedback;

import android.os.Bundle;
import android.widget.Spinner;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class selectCourse extends MainActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_course);

    Button course_next;
        course_next = findViewById(R.id.course_next);
        course_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openQuestions();
            }
        });
    }

    public void openQuestions() {
        Intent intent = new Intent(this, multChoice_survey.class);
        startActivity(intent);
    }
}