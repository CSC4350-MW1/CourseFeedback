package com.example.coursefeedback;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class openResponse extends MainActivity{
    String inputResponse;
    EditText questionInput;
    Button submit_btn;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question4);

        questionInput = (EditText) findViewById(R.id.openResponse);

        submit_btn = (Button) findViewById(R.id.submit_btn);
        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputResponse = questionInput.getText().toString();
            }
        });
    }
}

